document.addEventListener("DOMContentLoaded", loadCameras);

async function loadCameras() {
    try {
        const response = await fetch('http://127.0.0.1:8000/cameras/');
        if (response.ok) {
            const cameras = await response.json();
            const cameraTableBody = document.getElementById('cameraTableBody');
            cameraTableBody.innerHTML = '';
            cameras.forEach(camera => {
                const row = document.createElement('tr');
                row.innerHTML = `
                    <td><strong>${camera.id}</strong></td>
                    <td>${camera.ip}</td>
                    <td>${camera.location}</td>
                    <td><span class="badge ${camera.status === 'active' ? 'bg-label-success' : 'bg-label-warning'} me-1">${camera.status.charAt(0).toUpperCase() + camera.status.slice(1)}</span></td>
                    <td>
                        <div>
                            <button type="button" class="btn btn-primary btn-sm me-1" onclick="editCamera(${camera.id})">
                                <i class="bx bx-edit-alt"></i> Edit
                            </button>
                            <button type="button" class="btn btn-danger btn-sm" onclick="deleteCamera(${camera.id})">
                                <i class="bx bx-trash"></i> Delete
                            </button>
                        </div>
                    </td>
                `;
                cameraTableBody.appendChild(row);
            });
        } else {
            alert(`Error: ${response.statusText}`);
        }
    } catch (error) {
        alert(`Error: ${error.message}`);
    }
}

async function deleteCamera(cameraId) {
    if (!confirm('Are you sure you want to delete this camera?')) {
        return;
    }

    try {
        const response = await fetch(`http://127.0.0.1:8000/cameras/${cameraId}`, {
            method: 'DELETE',
        });

        if (response.ok) {
            alert('Camera deleted successfully');
            loadCameras();  // Refresh the camera list
        } else {
            const errorData = await response.json();
            alert(`Error: ${errorData.detail}`);
        }
    } catch (error) {
        alert(`Error: ${error.message}`);
    }
}

async function editCamera(cameraId) {
    window.location.href = `/public/UpdateCam.html?cameraId=${cameraId}`;
}
