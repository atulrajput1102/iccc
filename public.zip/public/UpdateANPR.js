// Function to fetch ANPR data for a specific ID
console.log("hello");
async function fetchANPRById(anprId) {
    try {
      const response = await fetch(`http://localhost:8000/anpr/${anprId}`);
      if (!response.ok) {
        throw new Error('Failed to fetch ANPR data');
      }
      const data = await response.json();
      return data;
    } catch (error) {
      console.error('Error fetching ANPR data:', error);
      alert('Failed to fetch ANPR data');
      return null;
    }
  }
  
  // Function to populate form fields with ANPR data
  async function populateForm(anprId) {
    try {
      const anprData = await fetchANPRById(anprId);
      if (anprData) {
        // Populate form fields with ANPR data
        document.getElementById('anprId').value = anprData.id;
        document.getElementById('vehicle_image').src = anprData.folder_url;
        document.getElementById('vehicle_no').value = anprData.vehicle_no;
        document.getElementById('geo_location').value = anprData.geo_location;
        document.getElementById('lattitude').value = anprData.lattitude;
        document.getElementById('lngitude').value = anprData.lngitude;
        document.querySelector(`input[name="status"][value="${anprData.status}"]`).checked = true;
        document.getElementById('speed').value = anprData.speed;
        document.getElementById('classification').value = anprData.classification;
      } else {
        console.error('ANPR data not found');
        alert('ANPR data not found');
      }
    } catch (error) {
      console.error('Error populating form:', error);
      alert('Failed to populate form');
    }
  }
  
  // Form submission handler for updating ANPR entry
  document.getElementById('updateForm').addEventListener('submit', async function(event) {
    event.preventDefault();
    const vehicle_image = document.getElementById('vehicle_image').src;
    const vehicle_no = document.getElementById('vehicle_no').value;
    const geo_location = document.getElementById('geo_location').value;
    const lattitude = document.getElementById('lattitude').value;
    const lngitude = document.getElementById('lngitude').value;
    const status = document.querySelector('input[name="status"]:checked').value;
    const speed = document.getElementById('speed').value;
    const classification = document.getElementById('classification').value;

    const anprId = document.getElementById('anprId').value;

    if (!anprId) {
        alert('ANPR ID is missing');
        return;
    }

    const updateData = {
        vehicle_image:vehicle_image,
        vehicle_no: vehicle_no,
        geo_location: geo_location,
        lattitude: lattitude,
        lngitude: lngitude,
        status: status,
        speed: speed,
        classification: classification
    };

    try {
        const response = await fetch(`http://localhost:8000/anpr/${anprId}`, {
            method: 'PUT',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(updateData)
        });

        if (!response.ok) {
            const errorData = await response.json();
            console.error('Update failed', errorData);
            throw new Error(`Update failed: ${JSON.stringify(errorData)}`);
        }

        alert('ANPR entry updated successfully');
        // Optionally redirect to another page or refresh current page
        window.location.href = '/public/html/ANPR.html';
    } catch (error) {
        console.error('Error updating ANPR entry:', error);
        alert(`Failed to update ANPR entry: ${error.message}`);
    }
});

  
  // Function to initialize the update form
  async function initUpdateForm() {
    // Parse URL parameters to get the 'id' parameter
    const urlParams = new URLSearchParams(window.location.search);
    const anprId = urlParams.get('id');
  
    console.log('Parsed ANPR ID from URL:', anprId);
  
    // Check if anprId is valid and populate the form
    if (anprId) {
      await populateForm(anprId);
    } else {
      console.error('ANPR ID not found in URL parameters');
      alert('ANPR ID not found');
    }
  }
  console.log(vehicle_no);
  // Initialize the update form when the page loads
  document.addEventListener('DOMContentLoaded', async () => {
    await initUpdateForm();
  });
  