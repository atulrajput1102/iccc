document.addEventListener('DOMContentLoaded', function() {
    document.querySelector('form').addEventListener('submit', addCamera);
});
