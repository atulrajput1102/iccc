document.getElementById('updateCameraForm').addEventListener('submit', async function (event) {
    event.preventDefault();

    const cameraId = 12; // This should be dynamically set or fetched
    const ipAddress = document.getElementById('ipAddress').value;
    const location = document.getElementById('location').value;
    const status = document.querySelector('input[name="status"]:checked').value;

    

    const response = await fetch(`http://127.0.0.1:8000/cameras/${cameraId}`, {
        method: 'PUT',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({
            ip: ipAddress,
            location: location,
            status: status
        })
    });

    if (response.ok) {
        const result = await response.json();
        alert('Camera updated successfully!');
        window.location.href = '/public/html/ListOfCameras.html';
    } else {
        alert(`Failed to update camera: ${errorData.detail}`);
    }
});

  
   
  