function validateForm() {
    var ipAddressInput = document.getElementById('ipAddress');
    var ipAddress = ipAddressInput.value.trim();

    var ipRegex = /^(\d{1,3})\.(\d{1,3})\.(\d{1,3})\.(\d{1,3})$/;

    if (!ipRegex.test(ipAddress)) {
        document.getElementById('ipError').textContent = 'Invalid IP address.';
        ipAddressInput.focus();
        return false;
    }

    document.getElementById('ipError').textContent = '';
    return true;
}