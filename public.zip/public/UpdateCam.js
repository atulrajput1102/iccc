document.addEventListener("DOMContentLoaded", () => {
    const urlParams = new URLSearchParams(window.location.search);
    const cameraId = urlParams.get('cameraId');
    
    if (cameraId) {
        loadCameraDetails(cameraId);
    }

    document.getElementById('updateCameraForm').addEventListener('submit', async function(event) {
        event.preventDefault();
        
        const ipAddress = document.getElementById('ipAddress').value;
        const location = document.getElementById('location').value;
        const status = document.querySelector('input[name="status"]:checked').value;

        try {
            const response = await fetch(`http://127.0.0.1:8000/cameras/${cameraId}`, {
                method: 'PUT',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({
                    ip: ipAddress,
                    location: location,
                    status: status
                })
            });

            if (response.ok) {
                alert('Camera updated successfully!');
                window.location.href = '/public/html/ListOfCameras.html';
            } else {
                const errorData = await response.json();
                alert(`Failed to update camera: ${errorData.detail}`);
            }
        } catch (error) {
            alert(`Failed to update camera: ${error.message}`);
        }
    });
});

async function loadCameraDetails(cameraId) {
    try {
        const response = await fetch(`http://127.0.0.1:8000/cameras/${cameraId}`,);
        
        if (response.ok) {
            const camera = await response.json();
            
            document.getElementById('cameraId').value = camera.id;
            document.getElementById('ipAddress').value = camera.ip;
            document.getElementById('location').value = camera.location;
            document.querySelector(`input[name="status"][value="${camera.status}"]`).checked = true;
        } else {
            alert('Failed to fetch camera details');
        }
    } catch (error) {
        alert(`Error: ${error.message}`);
    }
}
