

function addCamera(event) {
    event.preventDefault();

    if (!validateForm()) {
        return;
    }
   

    const ipAddress = document.getElementById('ipAddress').value;
    const location = document.getElementById('location').value;
    const status = document.querySelector('input[name="status"]:checked').value;

    const formData = {
        ip: ipAddress,
        location: location,
        status: status
    };

    fetch('http://127.0.0.1:8000/cameras/', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify(formData)
    })
    .then(response => {
        if (!response.ok) {
            throw new Error('Network response was not ok');
        }
        return response.json();
    })
    .then(data => {
        console.log('Success:', data);
        alert('Camera Added Successfully');
        window.location.href = '/public/html/ListOfCameras.html';
    })
    .catch(error => {
        console.error('Error:', error);
        alert('Failed to add camera. Please try again.' + error.message);
    });
}

document.querySelector('form').addEventListener('submit', addCamera);
