document.addEventListener('DOMContentLoaded', (event) => {
  fetchANPRData();
});

async function fetchANPRData() {
  try {
      const response = await fetch('http://127.0.0.1:8000/anpr/');
      const anprData = await response.json();
      populateTable(anprData);
  } catch (error) {
      console.error('Error fetching ANPR data:', error);
  }
}

function populateTable(anprData) {
  const tableBody = document.getElementById('anprTableBody');
  tableBody.innerHTML = '';  // Clear existing table data

  anprData.forEach((entry) => {
      const row = document.createElement('tr');

      row.innerHTML = `
          <td>${entry.id}</td>
          <td><img src="${entry.folder_url}" alt="Vehicle Image" width="100"></td>
          <td>${entry.vehicle_no}</td>
          <td>${entry.geo_location}</td>
          <td>${entry.lattitude}</td>
          <td>${entry.lngitude}</td>
          <td>${entry.status}</td>
          <td>${entry.speed}</td>
          <td>${entry.classification}</td>
          <td>
              <button class="btn btn-primary" onclick="editANPR(${entry.id})">Edit</button>
              
          </td>
      `;

      tableBody.appendChild(row);
  });
}

async function editANPR(anprId) {
  // Implement edit functionality
  console.log('Edit ANPR entry with ID:', anprId);
  window.location.href = `/public/html/UpdateANPR.html?id=${anprId}`;
}

// Populate the table when the page loads
document.addEventListener('DOMContentLoaded', async () => {
  await populateANPRTable();
});



